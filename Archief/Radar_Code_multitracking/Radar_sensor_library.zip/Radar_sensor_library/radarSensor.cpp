#include "radarSensor.h"

RadarSensor::RadarSensor(int8_t rx, int8_t tx) : _rx(rx), _tx(tx) {
  _serial = &Serial1;
}

void RadarSensor::begin() {
  _serial->begin(256000, SERIAL_8N1, _rx, _tx);
}

bool RadarSensor::update() {
  // Een pakket van de LD2450 is 30 bytes lang
  if (_serial->available() >= 30) {
    uint8_t head[4];
    _serial->readBytes(head, 4);

    // Check voor de juiste header: AA FF 03 00
    if (head[0] == 0xAA && head[1] == 0xFF && head[2] == 0x03 && head[3] == 0x00) {
      uint8_t data[26];
      _serial->readBytes(data, 26);

      // We pakken alleen Target 1 (eerste 8 bytes van de data)
      int16_t xRaw = data[0] | (data[1] << 8);
      int16_t yRaw = data[2] | (data[3] << 8);

      // Bit 15 is het teken (plus of min)
      float x = (xRaw & 0x7FFF) * ((xRaw & 0x8000) ? -1 : 1);
      float y = (yRaw & 0x7FFF) * ((yRaw & 0x8000) ? -1 : 1);

      if (y > 0 || abs(x) > 0) { // Iets gedetecteerd
        _target.detected = true;
        _target.distance = sqrt(x*x + y*y);
        
        // DE FIX: atan2(x, y) geeft 0 graden in het midden
        _target.angle = atan2(x, y) * (180.0 / PI);
      } else {
        _target.detected = false;
      }
      return true; // Nieuwe data verwerkt
    }
  }
  return false;
}

RadarTarget RadarSensor::getTarget() {
  return _target;
}